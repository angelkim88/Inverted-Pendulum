clc
g=9.8067;                    l=0.3;
M=0.5;                       m=0.2;
bx=0;                        btheta=0;
km=0.0377;                   kg=4.6;
rm=9.5;                      r=0.05;

ua=(km*kg)/(rm*r)

ub=((km^2)*(kg^2))/(rm*(r^2))