clc
num=[1.66 3.775 0];
den=[1 2.302 -31.2 -56.45 0];
pend=tf(num,den)

t=0:0.01:1;
[y,t]=impulse(pend,t);
plot(t,y),xlabel('Time[sec.]'),ylabel('\theta (t)')
%axsis([0 7 15E17 -15E19])