clc
clear all
g=9.8067;                    l=0.3;
M=0.5;                       m=0.2;
bx=0;                        btheta=0;
km=0.0377;                   kg=4.6;
rm=9.5;                      r=0.05;

A=[0 1 0 0;
   3*g*(M+m)/(l*(m+4*M)) 0 0 -3*(km^2)*(kg^2)/(rm*(r^2)*l*(m+4*M));
   0 0 0 1;
   3*m*g/(m+4*M) 0 0 (-4*(km^2)*(kg^2))/(rm*(r^2)*(m+4*M))]

B=[0; (3*km*kg)/(rm*r*l*(m+4*M)); 0; (4*km*kg)/rm*r*(m+4*M)]

C=[1 0 0 0]

D=[0]

[num,den]=ss2tf(A,B,C,D)

sys=tf(num,den)

kp=199.1243559;
ki=801.0166506;
kd=12.37505761;

contr=tf([kd kp ki],[1 0]);
%contr=tf([kp ki],[1 0]);% PI Control
%contr=tf([kd kp],1);% PD Control
sys_cl=feedback(sys,contr);
t=0:0.01:3;

figure(1)
impulse(sys_cl,t)
grid on

figure(2)
rlocus(sys_cl)
grid on

figure(3)
margin(sys_cl)
grid on

figure(4)
nichols(sys_cl)
grid on

figure(4)
nyquist(sys_cl)
grid on

