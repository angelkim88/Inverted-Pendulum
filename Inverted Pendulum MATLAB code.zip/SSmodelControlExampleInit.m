% Example for basic state-space model control & estimator design
% ryuhhh : http://www.ryuhhh.tistory.com

%% initialize

clc;
clear all;

A = [7 1 2;-1 0 3;0 3 8];
B = [3;2;-1];
C = [1 0 0];

eig(A)

% desired controller pole location
desiredControllerPole = [-2 -3 -4]

K = place(A,B,desiredControllerPole);   % same as K = acker(A,B,desiredControllerPole);
eig(A-B*K) 

% desired estimator pole location
desiredEstimatorPole = 2*[-2 -3 -4]

L = place(A',C',desiredEstimatorPole')';   % same as K = acker(A,B,desiredEstimatorPole);
eig(A-L*C)












