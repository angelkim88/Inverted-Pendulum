function[ ] = pend()

%define TF
num=[1.66 3.775 0];
den=[1 2.302 -31.2 -56.45 0];
pendulum = tf(num,den)
figure(1)
grid on
%ask user for controller
numc = input('numc?.........');
denc = input('denc?.........');
k    = input('K?............');

%view compensated system bode
contr = k*tf(numc,denc);
loop = contr*pendulum;
margin(loop)

%view compensated system nyquist
figure(2)
subplot (2,1,1)
nyquist(loop)
grid on
%view compensated CL system impulse response
subplot(2,1,2)
sys_cl = feedback(pendulum,contr);
impulse(sys_cl)
grid on
figure(3)
rlocus(loop)
grid on



